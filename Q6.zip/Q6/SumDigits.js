import React, { useState } from "react";
import { View, Text, TextInput, Button, Alert, StyleSheet } from "react-native";

export default function SumDigits() {
  const [num, setNum] = useState("");
  const [result, setResult] = useState(null);

  const calc = () => {
    const s = num.replace(/\D/g, "");
    if (!s) {
      setResult(null);
      Alert.alert("Lỗi", "Vui lòng nhập số hợp lệ.");
      return;
    }
    const first = Number(s[0]);
    const last = Number(s[s.length - 1]);
    setResult(first + last);
  };

  return (
    <View style={styles.card}>
      <Text style={styles.title}>2) Tổng chữ số đầu & cuối (State)</Text>
      <TextInput
        style={styles.input}
        placeholder="VD: 12057"
        keyboardType="numeric"
        value={num}
        onChangeText={setNum}
      />
      <Button title="Tính" onPress={calc} />
      {result !== null && <Text style={styles.result}>Kết quả: {result}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: 12, borderWidth: 1, borderColor: "#ddd", padding: 16, backgroundColor: "#fff", gap: 8, marginBottom: 16 },
  title: { fontSize: 18, fontWeight: "600", marginBottom: 6 },
  input: { borderWidth: 1, borderColor: "#ccc", borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, marginBottom: 8 },
  result: { marginTop: 8, fontWeight: "600" }
});
