import React, { useState } from "react";
import { View, Text, TextInput, Button, Alert, StyleSheet } from "react-native";

export default function MinThreeNumbers() {
  const [a, setA] = useState("");
  const [b, setB] = useState("");
  const [c, setC] = useState("");
  const [min, setMin] = useState(null);

  const calcMin = () => {
    if ([a, b, c].some(v => v.trim() === "")) {
      setMin(null);
      Alert.alert("Lỗi", "Vui lòng nhập đủ 3 số.");
      return;
    }
    const nums = [Number(a), Number(b), Number(c)];
    if (nums.some(x => Number.isNaN(x))) {
      setMin(null);
      Alert.alert("Lỗi", "Có giá trị không phải số.");
      return;
    }
    setMin(Math.min(...nums));
  };

  return (
    <View style={styles.card}>
      <Text style={styles.title}>3) Tìm min giữa ba số (State)</Text>
      <TextInput style={styles.input} placeholder="Số a" keyboardType="numeric" value={a} onChangeText={setA} />
      <TextInput style={styles.input} placeholder="Số b" keyboardType="numeric" value={b} onChangeText={setB} />
      <TextInput style={styles.input} placeholder="Số c" keyboardType="numeric" value={c} onChangeText={setC} />
      <Button title="Tính min" onPress={calcMin} />
      {min !== null && <Text style={styles.result}>Min = {min}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: 12, borderWidth: 1, borderColor: "#ddd", padding: 16, backgroundColor: "#fff", gap: 8, marginBottom: 16 },
  title: { fontSize: 18, fontWeight: "600", marginBottom: 6 },
  input: { borderWidth: 1, borderColor: "#ccc", borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, marginBottom: 8 },
  result: { marginTop: 8, fontWeight: "600" }
});
