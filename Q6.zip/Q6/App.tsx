import React from "react";
import { SafeAreaView, ScrollView, StyleSheet } from "react-native";
import EmployeeForm from "./Employee";
import SumDigits from "./SumDigits";
import MinThreeNumbers from "./MinThreeNumbers";
import HailstoneSequence from "./HailstoneSequence";

export default function App() {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        <EmployeeForm
          defaultValues={{ fullName: "", age: "", major: "" }}
          onSuccess={(e: { fullName: any; }) => console.log("Cập nhật cho:", e.fullName)}
        />
        <SumDigits />
        <MinThreeNumbers />
        <HailstoneSequence />
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({ container: { padding: 16 } });
