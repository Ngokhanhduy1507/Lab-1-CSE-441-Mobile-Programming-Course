import React, { useState } from "react";
import { View, Text, TextInput, Button, Alert, StyleSheet } from "react-native";

export default function HailstoneSequence() {
  const [n, setN] = useState("");
  const [seq, setSeq] = useState([]);

  const generate = () => {
    const start = Number(n);
    if (!Number.isInteger(start) || start <= 0) {
      setSeq([]);
      Alert.alert("Lỗi", "n phải là số nguyên dương (> 0).");
      return;
    }
    const arr = [start];
    let x = start;
    for (let i = 0; i < 10000 && x !== 1; i++) {
      x = x % 2 === 0 ? x / 2 : 3 * x + 1;
      arr.push(x);
    }
    setSeq(arr);
  };

  return (
    <View style={styles.card}>
      <Text style={styles.title}>4) Dãy Hailstone (State)</Text>
      <TextInput
        style={styles.input}
        placeholder="Nhập n > 0 (VD: 7)"
        keyboardType="numeric"
        value={n}
        onChangeText={setN}
      />
      <Button title="Sinh dãy" onPress={generate} />
      {seq.length > 0 && (
        <Text style={styles.result}>
          Dãy: {seq.join(" → ")}{"\n"}Độ dài: {seq.length}
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: 12, borderWidth: 1, borderColor: "#ddd", padding: 16, backgroundColor: "#fff", gap: 8, marginBottom: 16 },
  title: { fontSize: 18, fontWeight: "600", marginBottom: 6 },
  input: { borderWidth: 1, borderColor: "#ccc", borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, marginBottom: 8 },
  result: { marginTop: 8, fontWeight: "600" }
});
