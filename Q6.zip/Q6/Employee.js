import React, { useState } from "react";
import { View, Text, TextInput, Button, Alert, StyleSheet } from "react-native";

export default function EmployeeForm({ defaultValues = {}, onSuccess }) {
  const [fullName, setFullName] = useState(defaultValues.fullName ?? "");
  const [age, setAge] = useState(
    defaultValues.age !== undefined ? String(defaultValues.age) : ""
  );
  const [major, setMajor] = useState(defaultValues.major ?? "");

  const handleUpdate = () => {
    if (!fullName.trim() || !age.trim() || !major.trim()) {
      Alert.alert("Thiếu thông tin", "Vui lòng nhập đầy đủ.");
      return;
    }
    const ageNum = Number(age);
    if (Number.isNaN(ageNum)) {
      Alert.alert("Lỗi", "Tuổi phải là số.");
      return;
    }
    onSuccess && onSuccess({ fullName, age: ageNum, major });
  };

  return (
    <View style={styles.card}>
      <Text style={styles.title}>1) Thông tin nhân viên (Props)</Text>

      <Text>Họ tên</Text>
      <TextInput
        style={styles.input}
        placeholder="Nguyễn Văn A"
        value={fullName}
        onChangeText={setFullName}
      />

      <Text>Tuổi</Text>
      <TextInput
        style={styles.input}
        placeholder="22"
        keyboardType="numeric"
        value={age}
        onChangeText={setAge}
      />

      <Text>Chuyên ngành đào tạo</Text>
      <TextInput
        style={styles.input}
        placeholder="Mobile / React Native"
        value={major}
        onChangeText={setMajor}
      />

      <Button title="Cập nhật" onPress={handleUpdate} />
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: 12, borderWidth: 1, borderColor: "#ddd", padding: 16, backgroundColor: "#fff", gap: 8, marginBottom: 16 },
  title: { fontSize: 18, fontWeight: "600", marginBottom: 6 },
  input: { borderWidth: 1, borderColor: "#ccc", borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, marginBottom: 8 }
});
